import 'package:flutter/material.dart';

class DashboardPage extends StatefulWidget {
  @override
  _DashboardPageState createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  final List<Job> allJobs = [
    Job(id: 'WO-2025-001', title: 'Engine Oil Change & Inspection', customer: 'John Smith', status: 'In Progress', car: '2020 Ford F-150', plate: 'ABC-123', priority: 'Medium', time: '0h 30m'),
    Job(id: 'WO-2025-002', title: 'Brake System Repair', customer: 'Sarah', status: 'Pending', car: '2019 Toyota Camry', plate: 'XYZ-789', priority: 'High', time: '0h 0m'),
  ];

  String selectedFilter = 'All';

  @override
  Widget build(BuildContext context) {
    List<Job> filteredJobs = selectedFilter == 'All'
        ? allJobs
        : allJobs.where((job) => job.status == selectedFilter).toList();

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        elevation: 0,
        title: Text('Greenstem Workshop', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold)),
        iconTheme: IconThemeData(color: Colors.black),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Welcome back!', style: TextStyle(fontSize: 14, color: Colors.grey)),
            SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                _buildStatBox('2', 'Total Jobs'),
                _buildStatBox('0', "Today's Jobs"),
                _buildStatBox('1', 'In Progress'),
              ],
            ),
            SizedBox(height: 16),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: [
                  _buildFilterButton('All'),
                  _buildFilterButton('Pending'),
                  _buildFilterButton('In Progress'),
                  _buildFilterButton('Completed'),
                ],
              ),
            ),
            SizedBox(height: 16),
            Expanded(
              child: ListView.builder(
                itemCount: filteredJobs.length,
                itemBuilder: (context, index) {
                  return JobCard(job: filteredJobs[index]);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatBox(String count, String label) {
    return Container(
      width: 100,
      padding: EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 8,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          Text(count, style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
          SizedBox(height: 4),
          Text(label, style: TextStyle(fontSize: 12, color: Colors.grey)),
        ],
      ),
    );
  }

  Widget _buildFilterButton(String label) {
    bool isSelected = selectedFilter == label;

    return Padding(
      padding: EdgeInsets.only(right: 8),
      child: OutlinedButton(
        style: OutlinedButton.styleFrom(
          backgroundColor: isSelected ? Colors.green : Colors.white,
          side: BorderSide(color: Colors.green),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        ),
        onPressed: () => setState(() => selectedFilter = label),
        child: Text(
          label,
          style: TextStyle(
            color: isSelected ? Colors.white : Colors.green,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    );
  }
}

class JobCard extends StatelessWidget {
  final Job job;

  JobCard({required this.job});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,

        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 5),
          ),
        ],
      ),
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(job.id, style: TextStyle(fontSize: 12, color: Colors.grey)),
                Spacer(),
                _buildPriorityTag(job.priority),
                SizedBox(width: 8),
                StatusBadge(status: job.status),
              ],
            ),
            SizedBox(height: 8),
            Text(job.title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            SizedBox(height: 4),
            Text(job.description, style: TextStyle(fontSize: 14, color: Colors.grey)),
            SizedBox(height: 12),
            Row(
              children: [
                _buildCarInfo(job.car, job.plate),
                Spacer(),
              ],
            ),
            Row(
              children: [
                Icon(Icons.person, size: 16, color: Colors.grey),
                SizedBox(width: 4),
                Text(job.customer, style: TextStyle(fontSize: 12, color: Colors.grey)),
                SizedBox(width: 12),
                Icon(Icons.access_time, size: 16, color: Colors.grey),
                SizedBox(width: 4),
                Text(job.time, style: TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPriorityTag(String priority) {
    Color color = priority == 'High' ? Colors.red : Colors.orange;
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(priority.toUpperCase(), style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildCarInfo(String car, String plate) {
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey.shade200,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text('$car  |  $plate', style: TextStyle(fontSize: 12, color: Colors.black)),
    );
  }
}

class StatusBadge extends StatelessWidget {
  final String status;

  StatusBadge({required this.status});

  @override
  Widget build(BuildContext context) {
    Color badgeColor = status == 'Completed' ? Color(0xFF4CAF50) : status == 'In Progress' ? Colors.blue : Colors.orange;

    return Container(
      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: badgeColor.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Text(
        status.toUpperCase(),
        style: TextStyle(
          color: badgeColor,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

class Job {
  final String id;
  final String title;
  final String customer;
  final String status;
  final String car;
  final String plate;
  final String priority;
  final String time;
  final String description;

  Job({
    required this.id,
    required this.title,
    required this.customer,
    required this.status,
    required this.car,
    required this.plate,
    required this.priority,
    required this.time,
    this.description = 'Regular maintenance oil change with multi-point inspection',
  });
}
